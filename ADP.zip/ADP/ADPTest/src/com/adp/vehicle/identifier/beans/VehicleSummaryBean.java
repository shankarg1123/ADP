package com.adp.vehicle.identifier.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "vehicles")
@XmlAccessorType(XmlAccessType.FIELD)
public class VehicleSummaryBean {

	@XmlElement(name = "summary")
	private String summary;

	@XmlElement(name = "vehicle")
	private List<VehicleSummaryDetailBean> vehicleSummaryDetailBean = new ArrayList<VehicleSummaryDetailBean>();
	
	
	/**
	 * @return the vehicleSummaryDetailBean
	 */
	public List<VehicleSummaryDetailBean> getVehicleSummaryDetailBean() {
		return vehicleSummaryDetailBean;
	}

	/**
	 * @param vehicleSummaryDetailBean the vehicleSummaryDetailBean to set
	 */
	public void setVehicleSummaryDetailBean(
			List<VehicleSummaryDetailBean> vehicleSummaryDetailBean) {
		this.vehicleSummaryDetailBean = vehicleSummaryDetailBean;
	}

	/**
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * @param summary the summary to set
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}
}
