package com.adp.vehicle.identifier.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "vehicle")
public class VehicleBean {
	
	@XmlElement(name = "id" )
	private String id;
	
	@XmlElement(name = "frame" )
	private VehicleFrameBean frame;
	
	@XmlElement(name = "wheels" )
	private VehicleWheelsBean wheels;
	
	@XmlElement(name = "powertrain" )
	private String powertrain;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the frame
	 */
	public VehicleFrameBean getFrame() {
		return frame;
	}

	/**
	 * @param frame the frame to set
	 */
	public void setFrame(VehicleFrameBean frame) {
		this.frame = frame;
	}

	/**
	 * @return the wheels
	 */
	public VehicleWheelsBean getWheels() {
		return wheels;
	}

	/**
	 * @param wheels the wheels to set
	 */
	public void setWheels(VehicleWheelsBean wheels) {
		this.wheels = wheels;
	}

	/**
	 * @return the powertrain
	 */
	public String getPowertrain() {
		return powertrain;
	}

	/**
	 * @param powertrain the powertrain to set
	 */
	public void setPowertrain(String powertrain) {
		this.powertrain = powertrain;
	}
	
	

}
