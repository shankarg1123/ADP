package com.adp.vehicle.identifier.test;


import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Assert;
import org.junit.Test;

import com.adp.vehicle.identifier.beans.VehicleSummaryBean;
import com.adp.vehicle.identifier.main.VehicleIdentifier;
import com.adp.vehicle.identifier.main.VehicleIdentifierService;

public class TestJunit {

    private VehicleIdentifierService vehicleIdentifierService = new VehicleIdentifierService();
    File file = new File("src\\com\\adp\\vehicle\\identifier\\resource\\Vehicle.xml");
    String fileName = this.file.getAbsolutePath();
    private VehicleIdentifier vehicleIdentifier = new VehicleIdentifier();

    @Test
    public void isValidXml() {

        String xmlFileVehiclesDetail = this.vehicleIdentifierService.convertXMLFileToString(this.fileName);
        boolean valid = this.vehicleIdentifierService.isValidXML(xmlFileVehiclesDetail);
        Assert.assertTrue(valid);
    }

    @Test
    public void validateVehicleSummary() {

        String summary = "Summary : Car Count is 1, Big Wheel Count is 2, Bicycle Count is 1, Motorcycle Count is 1, Hang Glider Count is 1,";

        VehicleSummaryBean v = this.vehicleIdentifierService.getVehicleSummary(this.fileName);
        String str = v.getSummary().toString().trim();

        assertEquals(summary, str);

        System.out.println(VehicleIdentifier.convertObjectToXMLString(v));

    }

}
