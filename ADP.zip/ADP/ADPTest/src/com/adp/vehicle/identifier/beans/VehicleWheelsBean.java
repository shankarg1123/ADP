package com.adp.vehicle.identifier.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "wheels")
public class VehicleWheelsBean {
	
	@XmlElement(name = "wheel")
	private List<VehicleWheelBean> vehicleWheel = new ArrayList<VehicleWheelBean>();

	/**
	 * @return the vehicleWheel
	 */
	public List<VehicleWheelBean> getVehicleWheel() {
		return vehicleWheel;
	}

	/**
	 * @param vehicleWheel the vehicleWheel to set
	 */
	public void setVehicleWheel(List<VehicleWheelBean> vehicleWheel) {
		this.vehicleWheel = vehicleWheel;
	}

}
