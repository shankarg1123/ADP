package com.adp.vehicle.identifier.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.bind.JAXB;

import com.adp.vehicle.identifier.beans.VehicleSummaryBean;

public class VehicleIdentifier {

	public static void main(String[] args) {
		
		File file = new File("src\\com\\adp\\vehicle\\identifier\\resource\\Vehicle.xml");
		
		File outPutFile = new File("src\\com\\adp\\vehicle\\identifier\\resource\\Vehicle_Out_Put.xml");
		
		String fileName = file.getAbsolutePath();
		VehicleIdentifierService vehicleIdentifierService = new VehicleIdentifierService();
		VehicleSummaryBean vehicleSummary = vehicleIdentifierService.getVehicleSummary(fileName);
		
		System.out.println(convertObjectToXMLString(vehicleSummary));
		
		try {

			if (!outPutFile.exists()) {
				outPutFile.createNewFile();
			}
			
			FileWriter fw = new FileWriter(outPutFile.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(convertObjectToXMLString(vehicleSummary));
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static String convertObjectToXMLString(final Object class1) {

		StringWriter sw = new StringWriter();
		JAXB.marshal(class1, sw);
		return sw.toString();
	}
	
	
	
}
