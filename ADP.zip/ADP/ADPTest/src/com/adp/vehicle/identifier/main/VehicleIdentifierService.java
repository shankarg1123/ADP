package com.adp.vehicle.identifier.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.bind.JAXB;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.adp.vehicle.identifier.beans.VehicleBean;
import com.adp.vehicle.identifier.beans.VehicleFrameBean;
import com.adp.vehicle.identifier.beans.VehicleSummaryBean;
import com.adp.vehicle.identifier.beans.VehicleSummaryDetailBean;
import com.adp.vehicle.identifier.beans.VehicleWheelBean;
import com.adp.vehicle.identifier.beans.VehiclesBean;


public class VehicleIdentifierService {

	public VehicleSummaryBean getVehicleSummary(String fileName){
		
		VehiclesBean vehiclesBean = null;
		VehicleSummaryBean vehicleSummary = null;
		
		String xmlFileVehiclesDetail = convertXMLFileToString(fileName);
		
		try{
			if(xmlFileVehiclesDetail !=null && isValidXML(xmlFileVehiclesDetail)){
				
				vehiclesBean = (VehiclesBean)convertXMLStringToObject(xmlFileVehiclesDetail, VehiclesBean.class);
				
				if(vehiclesBean != null){
					
					List<VehicleBean> vehicleBeanList = vehiclesBean.getVehicleBean();
					
					vehicleSummary = vehicleType(vehicleBeanList);
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
			vehicleSummary.setSummary(e.getMessage());
		}
		return vehicleSummary;
		
	}
	
	private VehicleSummaryBean vehicleType(List<VehicleBean> vehicleList){
		List<String> vehicleTypeList = new ArrayList();
		List<VehicleSummaryDetailBean> vehicleSummaryDetailList = new ArrayList();
		String vehicleType = null;
		StringBuffer notCorrect = new StringBuffer();
		VehicleSummaryBean vehicleSummary = new VehicleSummaryBean();
		try{
			
			if(vehicleList != null && !vehicleList.isEmpty() && vehicleList.size() > 0){
				
				for(VehicleBean vehicleBean : vehicleList){
					
					VehicleSummaryDetailBean vehicleSummaryDetailBean = new VehicleSummaryDetailBean();
					String id = vehicleBean.getId();
					
					VehicleFrameBean frame = vehicleBean.getFrame();
					List<VehicleWheelBean> wheelsList = vehicleBean.getWheels().getVehicleWheel();
					int noOfWheels = wheelsList.size();
					Map wheelsType = new HashMap<String, String>();
					if(wheelsList !=null && !wheelsList.isEmpty() && wheelsList.size() > 0){
						for(VehicleWheelBean wheel : wheelsList){
							
							String position = wheel.getPosition();
							String material = wheel.getMaterial();
							wheelsType.put(position, material);
						}
					}
					
					boolean wheelsIdentification = validateWheels(wheelsType);
					if(noOfWheels == 3 && frame.getMaterial().equalsIgnoreCase("plastic") 
							&& vehicleBean.getPowertrain().equalsIgnoreCase("Human") && wheelsIdentification){
						
						vehicleType = "Big Wheel";
						
					}else if(noOfWheels == 2 && frame.getMaterial().equals("metal") 
							&& vehicleBean.getPowertrain().equalsIgnoreCase("Human") && wheelsIdentification){
						
						vehicleType = "Bicycle";
						
					}else if(noOfWheels == 2 && frame.getMaterial().equalsIgnoreCase("metal") 
							&& vehicleBean.getPowertrain().equalsIgnoreCase("Internal Combustion") && wheelsIdentification){
						
						vehicleType = "Motorcycle";
						
					} else if(noOfWheels == 0 && frame.getMaterial().equalsIgnoreCase("plastic") 
							&& vehicleBean.getPowertrain().equalsIgnoreCase("Bernoulli") && wheelsIdentification){
						
						vehicleType = "Hang Glider";
						
					}else if(noOfWheels == 4 && frame.getMaterial().equalsIgnoreCase("metal") 
							&& vehicleBean.getPowertrain().equalsIgnoreCase("Internal Combustion") && wheelsIdentification){
						
						vehicleType = "Car";
						
					}
					if(vehicleType !=null && !vehicleType.isEmpty()){
						vehicleSummaryDetailBean.setId(id);
						vehicleSummaryDetailBean.setVehicleType(vehicleType);
						vehicleSummaryDetailList.add(vehicleSummaryDetailBean);
						vehicleTypeList.add(vehicleType);
					}else{
						if(id != null && !id.isEmpty()){
							notCorrect.append(" and Vehicle id : \"").append(id).append( " \"");
						}
						notCorrect.append(" data are not correct, please correct it.");
					}
					
				}
				
				Set<String> uniqueSet = new HashSet<String>(vehicleTypeList);
				StringBuffer summary = new StringBuffer("Summary : ");
				for (String temp : uniqueSet) {
					summary.append(temp).append(" Count is ").append(Collections.frequency(vehicleTypeList, temp)).append(", ");
				}
				summary.append(notCorrect);
				vehicleSummary.setSummary(summary.toString());
				vehicleSummary.setVehicleSummaryDetailBean(vehicleSummaryDetailList);
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return vehicleSummary;
	}
	
	private boolean validateWheels(Map wheelsType){
		
		Set<Map.Entry<String, String>> entrySet = wheelsType.entrySet();
		boolean correctWheels = true;
		
			for (Entry entry : entrySet) {
				if(correctWheels){
				if(entry.getKey().equals("front") && entry.getValue().equals("plastic")){
					correctWheels = true;
				}else if(entry.getKey().equals("rear left") && entry.getValue().equals("plastic")){
					correctWheels = true;
				}else if(entry.getKey().equals("rear right") && entry.getValue().equals("plastic")){
					correctWheels = true;
				}else if(entry.getKey().equals("front") && entry.getValue().equals("metal")){
					correctWheels = true;
				}else if(entry.getKey().equals("rear") && entry.getValue().equals("metal")){
					correctWheels = true;
				}else if(entry.getKey().equals("front right") && entry.getValue().equals("metal")){
					correctWheels = true;
				}else if(entry.getKey().equals("front left") && entry.getValue().equals("metal")){
					correctWheels = true;
				}else if(entry.getKey().equals("rear right") && entry.getValue().equals("metal")){
					correctWheels = true;
				}else if(entry.getKey().equals("rear left") && entry.getValue().equals("metal")){
					correctWheels = true;
				}else if(entry.getKey().equals(null) && entry.getValue().equals("plastic")){
					correctWheels = true;
				}else{
					correctWheels = false;
				}
					
			}
		}
		return correctWheels;
	}
	public <T> Object convertXMLStringToObject(final String xmlFileVehiclesDetail, final Class<T> class1){
		Object returnObject = null;

		try {
			returnObject = (Object) JAXB.unmarshal(new StringReader(xmlFileVehiclesDetail), class1);
		} catch (Exception e) {
			 e.printStackTrace();
		}

		return returnObject;
	}
	
	
	public boolean isValidXML(final String xmlFileVehiclesDetail) {
		boolean isValidXML = false;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			InputSource source = new InputSource(new StringReader(xmlFileVehiclesDetail));
			Document document = factory.newDocumentBuilder().parse(source);
			isValidXML = true;
		} catch (ParserConfigurationException | SAXException | IOException e) {
			 e.printStackTrace();
			// return false;
		}
		return isValidXML;
	}
	
	public String convertXMLFileToString(String fileName) 
    { 
      try{ 
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance(); 
        InputStream inputStream = new FileInputStream(new File(fileName)); 
        org.w3c.dom.Document doc = documentBuilderFactory.newDocumentBuilder().parse(inputStream); 
        StringWriter stw = new StringWriter(); 
        Transformer serializer = TransformerFactory.newInstance().newTransformer(); 
        serializer.transform(new DOMSource(doc), new StreamResult(stw)); 
        return stw.toString(); 
      } 
      catch (Exception e) { 
        e.printStackTrace(); 
      } 
        return null; 
    }
}
