package com.adp.vehicle.identifier.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "vehicles")
public class VehiclesBean {
	
	@XmlElement(name = "vehicle")
	private List<VehicleBean> vehicleBean = new ArrayList<VehicleBean>();

	/**
	 * @return the vehicleBean
	 */
	public List<VehicleBean> getVehicleBean() {
		return vehicleBean;
	}

	/**
	 * @param vehicleBean the vehicleBean to set
	 */
	public void setVehicleBean(List<VehicleBean> vehicleBean) {
		this.vehicleBean = vehicleBean;
	}

}
